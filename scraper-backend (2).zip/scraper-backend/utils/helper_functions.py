def my_helper_function(input):
    # Perform some kind of operation on the input
    result = input
    return result