from .scraper import my_scrape_function
